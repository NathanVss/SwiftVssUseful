//
//  VssSetter.swift
//  Pods
//
//  Created by Nathan Vasse on 05/07/2016.
//
//
import SwiftyJSON

public class VssSetter {
    
    static func fillFromJSON(_ dest: AnyObject, json: JSON) {
        
        
    }
    
}
