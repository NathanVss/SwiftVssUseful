//
//  VssUseful.h
//  VssUseful
//
//  Created by Nathan Vasse on 05/07/2016.
//  Copyright © 2016 Nathan Vasse. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for VssUseful.
FOUNDATION_EXPORT double VssUsefulVersionNumber;

//! Project version string for VssUseful.
FOUNDATION_EXPORT const unsigned char VssUsefulVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VssUseful/PublicHeader.h>


